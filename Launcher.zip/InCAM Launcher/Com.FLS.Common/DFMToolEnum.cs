﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Com.FLS.Common
{
    public enum DFMToolEnum
    {
        InCAM = 0,
        Genesis = 1,
        GenFlex = 2,
        InsightPCBStart = 3,
        InsightPCBStop = 4,
        InCAM_Flex = 5
    }
}
