﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shuyz.Common.DataBase
{
    /// <summary>
    /// database session factory class
    /// </summary>
    public sealed class SessionFactory
    {
        private static SessionFactory _instance = null;
        private static object syncObject = new object();

        private DbConfig dbConfig;

        /// <summary>
        /// read db parameters
        /// </summary>
        private SessionFactory()
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        public static SessionFactory Instance
        {
            get
            {
                if (null == _instance)
                {
                    lock (syncObject)
                    {
                        if (null == _instance)
                        {
                            _instance = new SessionFactory();
                        }
                    }
                }

                return _instance;
            } 
        }

        /// <summary>
        /// produce a new IDbsession instance
        /// </summary>
        /// <returns></returns>
        public IDbSession OpenSession()
        {
            this.dbConfig = Config.Instance.dbConfig;

            if ("mssql" == this.dbConfig.ServerType)
            {
                return new MSDbSession(this.dbConfig.ServerAddress, this.dbConfig.ServerPort, this.dbConfig.DbName, this.dbConfig.UserName, this.dbConfig.PassWord);
            }
            else if("mysql" == this.dbConfig.ServerType)
            {
                return new MyDbSession(this.dbConfig.ServerAddress, this.dbConfig.ServerPort, this.dbConfig.DbName, this.dbConfig.UserName, this.dbConfig.PassWord);
            }
            else
            {
                return new PgDbSession(this.dbConfig.ServerAddress, this.dbConfig.ServerPort, this.dbConfig.DbName, this.dbConfig.UserName, this.dbConfig.PassWord);
            } 
        }
    }
}
