﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shuyz.Common.DataBase
{
    public abstract class IDbSession: IDisposable
    {
        public static readonly List<String> EmptyParameter = new List<String>(0);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverAddress"></param>
        /// <param name="serverPort"></param>
        /// <param name="dbName"></param>
        /// <param name="userName"></param>
        /// <param name="passWord"></param>
        public IDbSession(String serverAddress, String serverPort, String dbName, String userName, String passWord)
        {
           
        }

        /// <summary>
        /// 
        /// </summary>
        public abstract void Dispose();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverAddress"></param>
        /// <param name="serverPort"></param>
        /// <returns></returns>
        public abstract bool IsConnOK(string serverAddress, int serverPort);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public abstract bool BeginTransaction();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public abstract bool CommitTransaction();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public abstract bool RollBackTransaction();

        /// <summary>
        /// Execute Scalar, be very careful with bad cast of the return value
        /// </summary>
        /// <param name="sqlStr"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public abstract object ExecuteScalar(String sqlStr, List<String> parameters);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlStr"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public abstract IRecordSet ExcuteSelect(String sqlStr, List<String> parameters);

        /// <summary>
        /// Please remember to call BeginTransaction() before run NonQuery
        /// </summary>
        /// <param name="sqlStr"></param>
        /// <param name="parameters"></param>
        public abstract void ExcuteNonQuery(String sqlStr, List<String> parameters);
    }
}
