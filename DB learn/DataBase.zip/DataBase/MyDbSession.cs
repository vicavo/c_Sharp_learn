﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;

using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;

namespace Shuyz.Common.DataBase
{
    public sealed class MyDbSession : IDbSession
    {
        /* MSDN:
         * When the value of this key is set to true, any newly created connection will be added to the pool when closed by the application. 
         * In a next attempt to open the same connection, that connection will be drawn from the pool. Connections are considered 
         * the same if they have the same connection string. Different connections have different connection string
         */
        private readonly string sqlConStr = @"Server={0};Database={1};Uid={2};Pwd={3};Port={4};Pooling=true";
        
        private MySqlConnection conn = null;
        private MySqlTransaction transaction = null;

        private MyRecordSet recordSet = null;

        /// <summary>
        /// 
        /// </summary>
        public override void Dispose()
        {
            if (this.conn.State != System.Data.ConnectionState.Closed)
            {
                this.conn.Close();
            }

            this.recordSet = null;
            this.transaction = null;
            this.conn = null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverAddress"></param>
        /// <param name="serverPort"></param>
        /// <param name="dbName"></param>
        /// <param name="userName"></param>
        /// <param name="passWord"></param>
        public MyDbSession(String serverAddress, String serverPort, String dbName, String userName, String passWord):base(serverAddress, serverPort, dbName, userName, passWord)
        {
            bool result = this.IsConnOK(serverAddress, int.Parse(serverPort));
            if(!result)
            {
                throw new System.TimeoutException("MySQL Server is not connected: " + serverAddress + ":" + serverPort);
            }

            conn  = new MySqlConnection(String.Format(sqlConStr, serverAddress, dbName, userName, passWord, serverPort));
            conn.Open();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverAddress"></param>
        /// <param name="serverPort"></param>
        /// <returns></returns>
        public override bool IsConnOK(string serverAddress, int serverPort)
        {
            bool result = true;
            try
            {
                using (TcpClient tcp = new TcpClient(serverAddress, serverPort))
                {
                    if (!tcp.Connected)
                    {
                        result = false;
                    }
                    else
                    {
                        tcp.Close();
                    }
                }
            }
            catch
            {
                result = false;
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override bool BeginTransaction()
        {
            if (this.conn.State == System.Data.ConnectionState.Closed)
            {
                this.conn.Open();
            }

            this.transaction = this.conn.BeginTransaction();
  //          this.ExcuteNonQuery("SET autocommit = 0", IDbSession.EmptyParameter);

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override bool CommitTransaction()
        {
            this.transaction.Commit();

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override bool RollBackTransaction()
        {
            this.transaction.Rollback();

            return true;
        }

        /// <summary>
        /// create sql command according the parameter list, use DbSession.EmptyParameter if no parameter is specified
        /// </summary>
        /// <param name="sqlStr"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private MySqlCommand CreateCommand(String sqlStr, List<String> parameters)
        {
            sqlStr = Regex.Replace(sqlStr, @"ISNULL[\s]*\(", "IFNULL(", RegexOptions.IgnoreCase);

            if (0 == parameters.Count)
            {
                Logger.Instance.debugLog("Db operation: " + sqlStr);

                return new MySqlCommand(sqlStr, this.conn);
            }
            else
            {
                for (int i = 0; i < parameters.Count; i++)
                {
                    parameters[i] = parameters[i].Replace(",", "&#44;");

                    if ( "NULL" == parameters[i].ToUpper()) 
                    {
                         parameters[i] = parameters[i];
                    }
                    else
                    {
                        parameters[i] = "'" + parameters[i] + "'";
                    }                   
               }
                String finalStr = String.Format(sqlStr, parameters.ToArray());

                // do not log username and password
                if (-1 == finalStr.IndexOf("user_pass", StringComparison.OrdinalIgnoreCase))
                {
                    Logger.Instance.debugLog("Db operation: " + finalStr);
                }

                return new MySqlCommand(finalStr, this.conn);
            }
        }

        /// <summary>
        /// Execute Scalar, be very careful with bad cast of the return value
        /// </summary>
        /// <param name="sqlStr"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public override object ExecuteScalar(String sqlStr, List<String> parameters)
        {
            if (this.conn.State == System.Data.ConnectionState.Closed)
            {
                this.conn.Open();
            }
            
            MySqlCommand cmd = this.CreateCommand(sqlStr,  parameters);

            return (object)cmd.ExecuteScalar();
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlStr"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public override IRecordSet ExcuteSelect(String sqlStr, List<String> parameters)
        {
            if (this.conn.State == System.Data.ConnectionState.Closed)
            {
                this.conn.Open();
            }

            MySqlCommand cmd = this.CreateCommand(sqlStr,  parameters);

            this.recordSet = new MyRecordSet(cmd.ExecuteReader());

            return this.recordSet;

         //   return new RecordSet(cmd.ExecuteReader());
        }

        /// <summary>
        /// Please remember to call BeginTransaction() before run NonQuery
        /// </summary>
        /// <param name="sqlStr"></param>
        /// <param name="parameters"></param>
        public override void ExcuteNonQuery(String sqlStr, List<String> parameters)
        {
            // Check connection state at BeginTransaction()

            MySqlCommand cmd = this.CreateCommand(sqlStr, parameters);
            cmd.Transaction = this.transaction;

            cmd.ExecuteNonQuery();
           // cmd.EndExecuteNonQuery();
        }
    }
}
