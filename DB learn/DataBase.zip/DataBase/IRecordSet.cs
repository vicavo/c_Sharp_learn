﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shuyz.Common.DataBase
{
    public abstract class IRecordSet
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public abstract bool HasRows();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public abstract bool Read();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public abstract String GetString(int columnNo);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public abstract DateTime GetDateTime(int columnNo);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public abstract Int32 GetInt32(int columnNo);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public abstract Double GetDouble(int columnNo);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public abstract Decimal GetDecimal(int columnNo);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public abstract bool GetBoolean(int columnNo);

        /// <summary>
        ///  you MUST call this function after any select expression
        /// </summary>
        public abstract void CloseSelect();
    }
}
