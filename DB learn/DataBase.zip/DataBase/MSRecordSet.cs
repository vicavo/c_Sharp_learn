﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.SqlClient;

namespace Shuyz.Common.DataBase
{
    public class MSRecordSet: IRecordSet
    {
        private SqlDataReader reader = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_reader"></param>
        public MSRecordSet(SqlDataReader _reader)
        {
            this.reader = _reader;
        }

        /// <summary>
        /// 
        /// </summary>
        ~MSRecordSet()
        {
            if (!this.reader.IsClosed)
            {
                this.reader.Close();
            }
        }

        public override bool HasRows()
        {
            return this.reader.HasRows;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override bool Read()
        {
            return this.reader.Read();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public override String GetString(int columnNo)
        {
            if (System.DBNull.Value == this.reader[columnNo])
            {
                return "";
            }
            else
            {
                return this.reader.GetString(columnNo);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public override DateTime GetDateTime(int columnNo)
        {
            if (System.DBNull.Value == this.reader[columnNo])
            {
                return DateTime.MinValue;
            }
            else
            {
                return this.reader.GetDateTime(columnNo);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public override Int32 GetInt32(int columnNo)
        {
            if (System.DBNull.Value == this.reader[columnNo])
            {
                return 0;
            }
            else
            {
                return this.reader.GetInt32(columnNo);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public override Double GetDouble(int columnNo)
        {
            if (System.DBNull.Value == this.reader[columnNo])
            {
                return 0f;
            }
            else
            {
                return this.reader.GetDouble(columnNo);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public override Decimal GetDecimal(int columnNo)
        {
            if (System.DBNull.Value == this.reader[columnNo])
            {
                return 0;
            }
            else
            {
                return this.reader.GetDecimal(columnNo);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnNo"></param>
        /// <returns></returns>
        public override bool GetBoolean(int columnNo)
        {
            if (System.DBNull.Value == this.reader[columnNo])
            {
                return false;
            }
            else
            {
                return this.reader.GetBoolean(columnNo);
            }
        }

        /// <summary>
        ///  youMUST call this function after any select expression
        /// </summary>
        public override void CloseSelect()
        {
            if (!this.reader.IsClosed)
            {
                this.reader.Close();
            }
        }
    }
}
